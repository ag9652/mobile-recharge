package com.capgemini.takehome.Service;

import com.capgemini.takehome.Bean.Product;

public interface IProductService {
	public Product getProductDetails(int a1);
	public int getQuantity(int q1,int a1);
	public boolean geterror(int a12);


}
